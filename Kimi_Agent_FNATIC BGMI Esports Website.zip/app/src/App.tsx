import { useEffect } from 'react';
import Navbar from '@/components/Navbar';
import Hero from '@/sections/Hero';
import CinematicOperator from '@/sections/CinematicOperator';
import TeamPlayers from '@/sections/TeamPlayers';
import TeamManagement from '@/sections/TeamManagement';
import JoinCommunity from '@/sections/JoinCommunity';
import Footer from '@/sections/Footer';

function FloatingParticles() {
  const particles = Array.from({ length: 40 }, (_, i) => ({
    id: i,
    left: `${Math.random() * 100}%`,
    top: `${Math.random() * 100}%`,
    duration: 10 + Math.random() * 20,
    delay: Math.random() * 10,
    size: 2 + Math.random() * 3,
  }));

  return (
    <div className="fixed inset-0 pointer-events-none z-[50] overflow-hidden">
      {particles.map((p) => (
        <div
          key={p.id}
          className="absolute rounded-full"
          style={{
            left: p.left,
            top: p.top,
            width: p.size,
            height: p.size,
            background: 'radial-gradient(circle, rgba(255, 107, 0, 0.6), transparent)',
            animation: `emberFloat ${p.duration}s linear ${p.delay}s infinite`,
          }}
        />
      ))}
    </div>
  );
}

export default function App() {
  useEffect(() => {
    // Smooth scroll behavior
    document.documentElement.style.scrollBehavior = 'smooth';

    return () => {
      document.documentElement.style.scrollBehavior = '';
    };
  }, []);

  return (
    <div className="relative min-h-[100dvh]" style={{ background: '#0A0A0A' }}>
      <Navbar />
      <FloatingParticles />
      <main>
        <Hero />
        <CinematicOperator />
        <TeamPlayers />
        <TeamManagement />
        <JoinCommunity />
      </main>
      <Footer />
    </div>
  );
}
