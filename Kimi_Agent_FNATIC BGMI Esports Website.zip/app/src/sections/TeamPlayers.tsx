import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Instagram, Youtube } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface Player {
  number: string;
  role: string;
  name: string;
  description: string;
  stat1: string;
  stat1Value: string;
  stat2: string;
  stat2Value: string;
  bgImage: string;
  charImage: string;
}

const players: Player[] = [
  {
    number: '01',
    role: 'IGL',
    name: 'FNCxEliteRaYoP',
    description:
      'Strategic mastermind with exceptional game sense and leadership qualities in BGMI.',
    stat1: 'K/D',
    stat1Value: '1.32',
    stat2: 'WIN',
    stat2Value: '87%',
    bgImage: '/images/player-bg-1.jpg',
    charImage: '/images/player-char-1.png',
  },
  {
    number: '02',
    role: 'ENTRY ASSAULTER',
    name: 'FNCxJACKSPAROw',
    description:
      'Opening pressure player built for fast breaks, sharp trades, and close-range chaos.',
    stat1: 'K/D',
    stat1Value: '1.28',
    stat2: 'ENTRY',
    stat2Value: '85%',
    bgImage: '/images/player-bg-2.jpg',
    charImage: '/images/player-char-2.png',
  },
  {
    number: '03',
    role: 'ASSAULTER',
    name: 'FNCxSumitOP',
    description:
      'Rapid execution and high-impact positioning for consistent team pressure.',
    stat1: 'K/D',
    stat1Value: '1.35',
    stat2: 'CLUTCH',
    stat2Value: '88%',
    bgImage: '/images/player-bg-3.jpg',
    charImage: '/images/player-char-3.png',
  },
  {
    number: '04',
    role: 'POWER FRAGGER',
    name: 'FNCxHanish',
    description:
      'Steady damage dealer with disciplined aim in the final circles and heavy fights.',
    stat1: 'K/D',
    stat1Value: '1.25',
    stat2: 'CONSISTENCY',
    stat2Value: '82%',
    bgImage: '/images/player-bg-4.jpg',
    charImage: '/images/player-char-4.png',
  },
  {
    number: '05',
    role: 'SUBSTITUTE',
    name: 'FNCxSAKURAOP',
    description:
      'Flexible support option with strong map awareness and calm backup play.',
    stat1: 'K/D',
    stat1Value: '1.22',
    stat2: 'WIN',
    stat2Value: '81%',
    bgImage: '/images/player-bg-5.jpg',
    charImage: '/images/player-char-5.png',
  },
  {
    number: '06',
    role: 'SUBSTITUTE',
    name: 'FNCxAdarsh',
    description:
      'Reliable reserve with disciplined fundamentals and clean team discipline.',
    stat1: 'K/D',
    stat1Value: '1.20',
    stat2: 'WIN',
    stat2Value: '80%',
    bgImage: '/images/player-bg-6.jpg',
    charImage: '/images/player-char-6.png',
  },
];

function PlayerCard({ player }: { player: Player }) {
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const card = cardRef.current;
    if (!card) return;

    const layers = card.querySelectorAll<HTMLElement>('.layer');
    const depthFactors = [0.2, 0.5, 0.8, 1.0];

    const handleMouseMove = (e: MouseEvent) => {
      const rect = card.getBoundingClientRect();
      const x = (e.clientX - rect.left) / rect.width - 0.5;
      const y = (e.clientY - rect.top) / rect.height - 0.5;

      card.style.transform = `rotateY(${x * 10}deg) rotateX(${-y * 10}deg)`;

      layers.forEach((layer, i) => {
        layer.style.transform = `translateX(${x * 10 * depthFactors[i]}px) translateY(${y * 10 * depthFactors[i]}px) translateZ(${i * 15}px)`;
      });
    };

    const handleMouseLeave = () => {
      card.style.transform = 'rotateY(0) rotateX(0)';
      layers.forEach((layer) => {
        layer.style.transform = '';
      });
    };

    card.addEventListener('mousemove', handleMouseMove);
    card.addEventListener('mouseleave', handleMouseLeave);

    return () => {
      card.removeEventListener('mousemove', handleMouseMove);
      card.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, []);

  return (
    <div
      ref={cardRef}
      className="player-card relative w-full overflow-hidden cursor-pointer group"
      style={{
        aspectRatio: '16 / 10',
        border: '1px solid rgba(255, 69, 0, 0.15)',
        transformStyle: 'preserve-3d',
        perspective: '1000px',
        transition: 'transform 0.15s ease-out',
      }}
    >
      {/* Background Layer */}
      <div
        className="layer absolute inset-0 z-[1]"
        style={{ willChange: 'transform' }}
      >
        <img
          src={player.bgImage}
          alt=""
          className="w-full h-full object-cover"
          style={{ filter: 'brightness(0.4)' }}
        />
      </div>

      {/* Character Layer */}
      <div
        className="layer absolute inset-0 z-[2] flex items-end justify-center"
        style={{ willChange: 'transform' }}
      >
        <img
          src={player.charImage}
          alt={player.name}
          className="h-[85%] object-contain object-bottom"
        />
      </div>

      {/* Logo Watermark Layer */}
      <div
        className="layer absolute top-4 right-4 z-[3] opacity-50"
        style={{ willChange: 'transform' }}
      >
        <svg width="60" height="60" viewBox="0 0 64 64" fill="none">
          <path
            d="M32 4L8 16V32C8 46.4 18.4 58.4 32 62C45.6 58.4 56 46.4 56 32V16L32 4Z"
            stroke="#FF4500"
            strokeWidth="1.5"
            fill="none"
          />
          <path
            d="M22 24H38M22 24V42M22 32H34"
            stroke="#FF4500"
            strokeWidth="2.5"
            strokeLinecap="round"
          />
        </svg>
      </div>

      {/* Content Layer */}
      <div
        className="layer absolute bottom-0 left-0 right-0 z-[4] p-6"
        style={{
          background:
            'linear-gradient(to top, rgba(10,10,10,0.95) 0%, transparent 100%)',
          willChange: 'transform',
        }}
      >
        <div className="flex items-start justify-between mb-2">
          <div>
            <span className="font-rajdhani font-bold text-[48px] text-fnc-orange leading-none block">
              {player.number}
            </span>
            <span
              className="font-rajdhani font-semibold text-[11px] uppercase tracking-wider inline-block mt-1 px-2.5 py-1"
              style={{
                background: 'rgba(255, 69, 0, 0.2)',
                color: '#FF4500',
              }}
            >
              {player.role}
            </span>
          </div>
        </div>

        <h3 className="font-rajdhani font-bold text-[22px] text-white mb-1">
          {player.name}
        </h3>

        <p className="font-inter font-normal text-[13px] text-fnc-textMuted mb-3 line-clamp-2">
          {player.description}
        </p>

        <div className="flex items-center gap-6 mb-3">
          <span className="font-rajdhani font-bold text-[18px] text-white">
            {player.stat1} {player.stat1Value}
          </span>
          <span className="font-rajdhani font-bold text-[18px] text-fnc-orange">
            {player.stat2} {player.stat2Value}
          </span>
        </div>

        <div className="flex items-center gap-3">
          <a
            href="#"
            className="text-fnc-textMuted hover:text-fnc-orange transition-colors duration-300"
            onClick={(e) => e.preventDefault()}
          >
            <Instagram size={20} />
          </a>
          <a
            href="#"
            className="text-fnc-textMuted hover:text-fnc-orange transition-colors duration-300"
            onClick={(e) => e.preventDefault()}
          >
            <Youtube size={20} />
          </a>
        </div>
      </div>

      {/* Scanline Glow Border */}
      <div
        className="absolute inset-[-2px] pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-300"
        style={{
          padding: '2px',
          background:
            'linear-gradient(0deg, transparent, rgba(255, 69, 0, 0.3), transparent)',
          WebkitMask:
            'linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0)',
          WebkitMaskComposite: 'xor',
          maskComposite: 'exclude',
          animation: 'scanlineMove 3s linear infinite',
        }}
      />
    </div>
  );
}

export default function TeamPlayers() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const tunnelRef = useRef<any>(null);

  useEffect(() => {
    if (!sectionRef.current || !headingRef.current || !cardsRef.current) return;

    // Heading animation
    const ctx = gsap.context(() => {
      gsap.fromTo(
        headingRef.current,
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      // Cards stagger animation
      const cards = cardsRef.current!.querySelectorAll('.player-card-wrapper');
      gsap.fromTo(
        cards,
        { opacity: 0, y: 60 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          stagger: 0.1,
          scrollTrigger: {
            trigger: cardsRef.current,
            start: 'top 85%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);

    // Text Tunnel
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx2d = canvas.getContext('2d');
      if (ctx2d) {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;

        class TextTunnel {
          canvas: HTMLCanvasElement;
          ctx: CanvasRenderingContext2D;
          width: number;
          height: number;
          fov: number;
          cameraZ: number;
          strings: Array<{
            word: string;
            x: number;
            y: number;
            z: number;
            speed: number;
            weight: string;
          }>;
          frame: number;
          words: string[];
          _update: () => void;
          active: boolean;

          constructor(c: HTMLCanvasElement) {
            this.canvas = c;
            this.ctx = c.getContext('2d')!;
            this.width = c.width = window.innerWidth;
            this.height = c.height = window.innerHeight;
            this.fov = 900;
            this.cameraZ = 0;
            this.strings = [];
            this.frame = 0;
            this.words = [
              'ELITE', 'RAID', 'SQUAD', 'DROP', 'ZONE', 'CHICKEN',
              'LEADERBOARD', 'RUSH', 'CLUTCH', 'FNCORG', 'TACTICAL',
              'SUPREMACY', 'VICTORY', 'FIREPOWER', 'DOMINATE', 'BGMI',
            ];
            this.active = false;
            this._update = this.update.bind(this);

            window.addEventListener('resize', () => {
              if (!canvas) return;
              this.width = canvas.width = window.innerWidth;
              this.height = canvas.height = window.innerHeight;
            });

            this.populate();
          }

          start() {
            this.active = true;
            this._update();
          }

          stop() {
            this.active = false;
          }

          bindScroll(scrollY: number) {
            this.cameraZ = scrollY;
          }

          update() {
            if (!this.active) return;

            this.ctx.fillStyle = 'rgba(10, 10, 10, 0.3)';
            this.ctx.fillRect(0, 0, this.width, this.height);

            for (const s of this.strings) {
              s.z -= s.speed;
              this.drawString(s);
            }

            this.strings = this.strings.filter(
              (s) => s.z > this.cameraZ - this.fov
            );

            while (this.strings.length < 30) {
              this.populate(true);
            }

            this.frame++;
            requestAnimationFrame(this._update);
          }

          drawString(s: (typeof this.strings)[0]) {
            const z = s.z - this.cameraZ;
            if (z <= 0) return;
            const scale = this.fov / (this.fov + z);
            const x2d = s.x * scale + this.width / 2;
            const y2d = s.y * scale + this.height / 2;
            const alpha = Math.min(1, Math.max(0, 1 - z / 2000));

            this.ctx.font = `${s.weight} ${20 * scale}px Rajdhani`;
            this.ctx.fillStyle = `rgba(255, 69, 0, ${alpha * 0.7})`;
            this.ctx.textAlign = 'center';
            this.ctx.fillText(s.word, x2d, y2d);
          }

          populate(onlyFar = false) {
            this.strings.push({
              word: this.words[Math.floor(Math.random() * this.words.length)],
              x: (Math.random() * 2 - 1) * this.width * 1.5,
              y: (Math.random() * 2 - 1) * this.height * 1.5,
              z: onlyFar
                ? this.cameraZ + 2000 + Math.random() * 1000
                : this.cameraZ + 200 + Math.random() * 2000,
              speed: 2 + Math.random() * 3,
              weight: Math.random() > 0.5 ? '700' : '400',
            });
          }
        }

        tunnelRef.current = new TextTunnel(canvas);

        // IntersectionObserver to control tunnel visibility
        const observer = new IntersectionObserver(
          (entries) => {
            entries.forEach((entry) => {
              if (entry.isIntersecting) {
                tunnelRef.current.start();
              } else {
                tunnelRef.current.stop();
              }
            });
          },
          { threshold: 0.1 }
        );
        observer.observe(sectionRef.current);

        // Scroll binding
        const handleScroll = () => {
          if (tunnelRef.current && sectionRef.current) {
            const rect = sectionRef.current.getBoundingClientRect();
            const sectionScroll = -rect.top + window.scrollY;
            tunnelRef.current.bindScroll(sectionScroll);
          }
        };
        window.addEventListener('scroll', handleScroll, { passive: true });

        return () => {
          observer.disconnect();
          window.removeEventListener('scroll', handleScroll);
          if (tunnelRef.current) tunnelRef.current.stop();
        };
      }
    }

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="team-players"
      ref={sectionRef}
      className="relative w-full py-[120px] px-6 md:px-10 overflow-hidden"
      style={{ background: '#0A0A0A' }}
    >
      {/* Text Tunnel Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full z-0 pointer-events-none"
      />

      <div className="relative z-[1] max-w-[1280px] mx-auto">
        {/* Heading */}
        <div ref={headingRef} className="text-center mb-16">
          <p className="font-rajdhani font-semibold text-[12px] uppercase tracking-[0.12em] text-fnc-orange mb-4">
            STARTING LINEUP
          </p>
          <h2 className="font-rajdhani font-bold text-[40px] md:text-[56px] uppercase text-white leading-tight mb-4">
            TEAM PLAYERS
          </h2>
          <p className="font-inter font-normal text-[18px] text-fnc-textMuted max-w-[500px] mx-auto">
            Six warriors. One mission. Total domination.
          </p>
        </div>

        {/* Player Cards Grid */}
        <div
          ref={cardsRef}
          className="grid grid-cols-1 md:grid-cols-2 gap-10"
        >
          {players.map((player) => (
            <div key={player.number} className="player-card-wrapper">
              <PlayerCard player={player} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
