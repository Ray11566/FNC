import { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import FncorgLogo from '@/components/FncorgLogo';

gsap.registerPlugin(ScrollTrigger);

function createBookTextures() {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#1A0F00';
  ctx.fillRect(0, 0, 128, 128);

  for (let i = 0; i < 5000; i++) {
    ctx.fillStyle = `rgba(0, 0, 0, ${Math.random() * 0.1})`;
    ctx.fillRect(Math.random() * 128, Math.random() * 128, 2, 2);
    ctx.fillStyle = `rgba(255, 100, 0, ${Math.random() * 0.05})`;
    ctx.fillRect(Math.random() * 128, Math.random() * 128, 2, 2);
  }

  ctx.strokeStyle = 'rgba(255, 165, 0, 0.3)';
  ctx.lineWidth = 2;
  ctx.strokeRect(4, 4, 120, 120);

  const coverTexture = new THREE.CanvasTexture(canvas);

  const pageCanvas = document.createElement('canvas');
  pageCanvas.width = 64;
  pageCanvas.height = 64;
  const pctx = pageCanvas.getContext('2d')!;

  pctx.fillStyle = '#F5F0E8';
  pctx.fillRect(0, 0, 64, 64);

  const grad = pctx.createLinearGradient(0, 0, 8, 0);
  grad.addColorStop(0, '#E8E0D0');
  grad.addColorStop(1, '#F5F0E8');
  pctx.fillStyle = grad;
  pctx.fillRect(0, 0, 8, 64);

  const pageTexture = new THREE.CanvasTexture(pageCanvas);

  return { coverTexture, pageTexture };
}

function createRoundedBox(
  w: number,
  h: number,
  d: number,
  r: number,
  s: number
): THREE.BoxGeometry {
  const geometry = new THREE.BoxGeometry(w, h, d, s, s, s);
  const positionAttribute = geometry.attributes.position;

  for (let i = 0; i < positionAttribute.count; i++) {
    const x = positionAttribute.getX(i);
    const y = positionAttribute.getY(i);
    const z = positionAttribute.getZ(i);

    const signX = Math.sign(x);
    const signY = Math.sign(y);
    const signZ = Math.sign(z);

    const radiusX = Math.abs(x) - (w / 2 - r);
    const radiusY = Math.abs(y) - (h / 2 - r);
    const radiusZ = Math.abs(z) - (d / 2 - r);

    if (radiusX > 0 || radiusY > 0 || radiusZ > 0) {
      const len =
        Math.sqrt(radiusX * radiusX + radiusY * radiusY + radiusZ * radiusZ) || 1;
      const normalizedRadiusX = (radiusX / len) * r;
      const normalizedRadiusY = (radiusY / len) * r;
      const normalizedRadiusZ = (radiusZ / len) * r;

      positionAttribute.setXYZ(
        i,
        signX * (Math.abs(x) - radiusX + normalizedRadiusX),
        signY * (Math.abs(y) - radiusY + normalizedRadiusY),
        signZ * (Math.abs(z) - radiusZ + normalizedRadiusZ)
      );
    }
  }

  geometry.computeVertexNormals();
  return geometry;
}

function createBookMesh(textures: {
  coverTexture: THREE.CanvasTexture;
  pageTexture: THREE.CanvasTexture;
}): THREE.Group {
  const bookGroup = new THREE.Group();

  const coverMaterial = new THREE.MeshStandardMaterial({
    map: textures.coverTexture,
    roughness: 0.8,
    metalness: 0.1,
  });

  const pageMaterial = new THREE.MeshStandardMaterial({
    map: textures.pageTexture,
    roughness: 0.9,
  });

  const coverGeom = createRoundedBox(3, 4.2, 0.15, 0.05, 4);
  const coverMesh = new THREE.Mesh(coverGeom, coverMaterial);
  coverMesh.position.z = -0.1;

  const backGeom = createRoundedBox(3, 4.2, 0.15, 0.05, 4);
  const backMesh = new THREE.Mesh(backGeom, coverMaterial);
  backMesh.position.z = 0.6;

  const spineGeom = createRoundedBox(0.8, 4.2, 0.15, 0.05, 4);
  const spineMesh = new THREE.Mesh(spineGeom, coverMaterial);
  spineMesh.position.x = -1.5;
  spineMesh.rotation.y = Math.PI / 2;

  const pageBlockGeom = createRoundedBox(2.8, 4.0, 0.5, 0.02, 2);
  const pageBlock = new THREE.Mesh(pageBlockGeom, pageMaterial);
  pageBlock.position.set(0.1, 0, 0.25);

  bookGroup.add(coverMesh);
  bookGroup.add(backMesh);
  bookGroup.add(spineMesh);
  bookGroup.add(pageBlock);

  return bookGroup;
}

interface BookPage {
  title: string;
  subtitle: string;
  content: string;
}

const pages: BookPage[] = [
  {
    title: 'FNCORG BGMI',
    subtitle: '',
    content: 'Firepower & Neutralization Corps\nOffensive Recon Group\n\nEstablished October 1, 2025',
  },
  {
    title: 'Piyush',
    subtitle: 'Owner',
    content:
      'Founder and owner of FNATIC ORG BGMI team. Leading the organization with a vision for excellence in competitive gaming.',
  },
  {
    title: 'Adarsh Singh Bhandri',
    subtitle: 'Manager',
    content:
      'Team manager responsible for player development, tournament coordination, and strategic planning.',
  },
  {
    title: 'FNCORG',
    subtitle: 'Our Mission',
    content:
      'To dominate the BGMI competitive scene through disciplined teamwork, strategic excellence, and unwavering dedication.\n\nContact: fncorg@esports.gg',
  },
];

export default function TeamManagement() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [currentPage, setCurrentPage] = useState(0);
  const headingRef = useRef<HTMLDivElement>(null);
  const initRef = useRef(false);

  useEffect(() => {
    if (initRef.current) return;
    initRef.current = true;

    const canvasElement = canvasRef.current;
    if (!canvasElement) return;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color('#0A0A0A');

    const camera = new THREE.PerspectiveCamera(45, 1, 0.1, 100);
    camera.position.set(4, 3, 6);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({
      canvas: canvasElement,
      antialias: true,
    });
    renderer.setSize(500, 500);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.4);
    scene.add(ambientLight);

    const spotLight = new THREE.SpotLight(0xffaa55, 2);
    spotLight.position.set(3, 5, 3);
    spotLight.angle = Math.PI / 4;
    spotLight.penumbra = 0.5;
    spotLight.castShadow = true;
    scene.add(spotLight);

    const fillLight = new THREE.DirectionalLight(0xff6600, 0.5);
    fillLight.position.set(-2, 2, 2);
    scene.add(fillLight);

    // Book
    const textures = createBookTextures();
    const book = createBookMesh(textures);
    scene.add(book);

    // Mouse rotation
    let mouseX = 0;
    let mouseY = 0;
    const targetRotation = { x: 0, y: 0 };

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvasElement.getBoundingClientRect();
      mouseX = ((e.clientX - rect.left) / rect.width - 0.5) * 2;
      mouseY = ((e.clientY - rect.top) / rect.height - 0.5) * 2;
    };
    canvasElement.addEventListener('mousemove', handleMouseMove);

    let animationId: number;
    const animate = () => {
      animationId = requestAnimationFrame(animate);

      targetRotation.x = mouseY * 0.2;
      targetRotation.y = mouseX * 0.3;

      book.rotation.x += (targetRotation.x - book.rotation.x) * 0.05;
      book.rotation.y += (targetRotation.y - book.rotation.y) * 0.05;

      renderer.render(scene, camera);
    };
    animate();

    return () => {
      cancelAnimationFrame(animationId);
      canvasElement.removeEventListener('mousemove', handleMouseMove);
      renderer.dispose();
    };
  }, []);

  useEffect(() => {
    if (!headingRef.current || !sectionRef.current) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        headingRef.current,
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const nextPage = () => setCurrentPage((prev) => (prev + 1) % pages.length);
  const prevPage = () =>
    setCurrentPage((prev) => (prev - 1 + pages.length) % pages.length);

  return (
    <section
      id="team-management"
      ref={sectionRef}
      className="relative w-full py-[120px] px-6 md:px-10"
      style={{ background: '#0A0A0A' }}
    >
      <div className="max-w-[1280px] mx-auto">
        {/* Heading */}
        <div ref={headingRef} className="text-center mb-16">
          <p className="font-rajdhani font-semibold text-[12px] uppercase tracking-[0.12em] text-fnc-orange mb-4">
            TEAM MANAGEMENT
          </p>
          <h2 className="font-rajdhani font-bold text-[40px] md:text-[56px] uppercase text-white leading-tight mb-4">
            THE ARCHIVES
          </h2>
          <p className="font-inter font-normal text-[18px] text-fnc-textMuted">
            Flip through the pages to discover our leadership.
          </p>
        </div>

        {/* Book Display */}
        <div className="flex flex-col lg:flex-row items-center justify-center gap-12">
          {/* 3D Book Canvas */}
          <div className="relative flex-shrink-0">
            <canvas
              ref={canvasRef}
              className="rounded-lg"
              style={{
                width: '100%',
                maxWidth: '500px',
                height: 'auto',
                aspectRatio: '1',
              }}
            />
            <p className="text-center font-inter text-[13px] text-white/30 mt-4">
              Drag to rotate • Click pages to navigate
            </p>
          </div>

          {/* Page Content */}
          <div className="flex flex-col items-center lg:items-start max-w-[400px]">
            <FncorgLogo size={48} className="mb-6" />

            {/* Page Navigation */}
            <div className="flex items-center gap-4 mb-8">
              <button
                onClick={prevPage}
                className="w-10 h-10 flex items-center justify-center border border-fnc-border text-fnc-orange hover:bg-[rgba(255,69,0,0.1)] transition-colors duration-300"
              >
                ←
              </button>
              <span className="font-rajdhani font-semibold text-[14px] text-fnc-textMuted">
                PAGE {currentPage + 1} / {pages.length}
              </span>
              <button
                onClick={nextPage}
                className="w-10 h-10 flex items-center justify-center border border-fnc-border text-fnc-orange hover:bg-[rgba(255,69,0,0.1)] transition-colors duration-300"
              >
                →
              </button>
            </div>

            {/* Page Display */}
            <div
              className="w-full p-8 border border-fnc-border"
              style={{
                background: 'rgba(20, 20, 20, 0.8)',
                minHeight: '280px',
              }}
            >
              <h3 className="font-rajdhani font-bold text-[28px] text-white mb-2">
                {pages[currentPage].title}
              </h3>
              {pages[currentPage].subtitle && (
                <p className="font-rajdhani font-semibold text-[14px] uppercase tracking-wider text-fnc-orange mb-4">
                  {pages[currentPage].subtitle}
                </p>
              )}
              <p className="font-inter font-normal text-[15px] text-fnc-textMuted leading-relaxed whitespace-pre-line">
                {pages[currentPage].content}
              </p>
            </div>

            {/* Page Dots */}
            <div className="flex items-center gap-2 mt-6">
              {pages.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrentPage(i)}
                  className="w-2 h-2 rounded-full transition-all duration-300"
                  style={{
                    background:
                      i === currentPage ? '#FF4500' : 'rgba(255,255,255,0.3)',
                    transform: i === currentPage ? 'scale(1.3)' : 'scale(1)',
                  }}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
