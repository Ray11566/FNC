import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import FncorgLogo from '@/components/FncorgLogo';

gsap.registerPlugin(ScrollTrigger);

function EmberParticles() {
  const particles = Array.from({ length: 25 }, (_, i) => ({
    id: i,
    left: `${Math.random() * 100}%`,
    bottom: `${Math.random() * 30}%`,
    duration: 8 + Math.random() * 12,
    delay: Math.random() * 8,
    size: 3 + Math.random() * 4,
  }));

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden z-[1]">
      {particles.map((p) => (
        <div
          key={p.id}
          className="absolute rounded-full"
          style={{
            left: p.left,
            bottom: p.bottom,
            width: p.size,
            height: p.size,
            background: 'radial-gradient(circle, #FF6B00, transparent)',
            animation: `emberFloat ${p.duration}s linear ${p.delay}s infinite`,
          }}
        />
      ))}
    </div>
  );
}

export default function CinematicOperator() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!contentRef.current || !sectionRef.current) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        contentRef.current,
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative w-full min-h-[100dvh] overflow-hidden flex items-center justify-center"
    >
      {/* Background Video */}
      <video
        autoPlay
        muted
        loop
        playsInline
        className="absolute inset-0 w-full h-full object-cover z-0"
      >
        <source src="/videos/bg-smoke.mp4" type="video/mp4" />
      </video>

      {/* Gradient Overlay */}
      <div
        className="absolute inset-0 z-[1]"
        style={{
          background:
            'linear-gradient(to bottom, rgba(10,10,10,0.3) 0%, rgba(10,10,10,0.7) 50%, rgba(10,10,10,0.95) 100%)',
        }}
      />

      {/* Ember Particles */}
      <EmberParticles />

      {/* Content */}
      <div
        ref={contentRef}
        className="relative z-[2] text-center px-6 flex flex-col items-center"
      >
        <FncorgLogo size={80} className="mb-6" />

        <p className="font-rajdhani font-semibold text-[14px] uppercase tracking-[0.1em] text-fnc-orange mb-4">
          FNCORG BGMI
        </p>

        <h2 className="font-rajdhani font-bold text-[40px] md:text-[64px] uppercase text-white leading-tight mb-6">
          TACTICAL SUPERIORITY
        </h2>

        <p className="font-inter font-normal text-[16px] md:text-[18px] text-fnc-textMuted max-w-[560px]">
          Competing at the highest level of Battlegrounds Mobile India
        </p>

        <p className="absolute bottom-8 right-8 font-inter font-normal text-[13px] text-white/40 hidden md:block">
          Established October 1, 2025
        </p>
      </div>
    </section>
  );
}
