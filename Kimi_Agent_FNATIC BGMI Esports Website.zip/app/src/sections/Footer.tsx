import FncorgLogo from '@/components/FncorgLogo';

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer
      className="relative w-full py-[60px] px-6 md:px-10 border-t"
      style={{
        background: '#0A0A0A',
        borderColor: 'rgba(255, 69, 0, 0.1)',
      }}
    >
      <div className="max-w-[1280px] mx-auto">
        {/* Row 1 */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-10">
          <div className="flex items-center gap-3">
            <FncorgLogo size={32} />
            <span className="font-rajdhani font-bold text-[16px] text-white">
              FNATIC ORG
            </span>
          </div>

          <div className="flex items-center gap-6">
            <a
              href="#"
              className="font-inter font-normal text-[14px] text-fnc-textMuted hover:text-fnc-orange transition-colors duration-300 hover:underline"
              onClick={(e) => e.preventDefault()}
            >
              Instagram
            </a>
            <a
              href="#"
              className="font-inter font-normal text-[14px] text-fnc-textMuted hover:text-fnc-orange transition-colors duration-300 hover:underline"
              onClick={(e) => e.preventDefault()}
            >
              YouTube
            </a>
          </div>
        </div>

        {/* Row 2 */}
        <div className="text-center mb-6">
          <p className="font-inter font-normal text-[13px] text-fnc-textMuted">
            BGMI Esports Organization
          </p>
        </div>

        {/* Row 3 */}
        <div className="text-center">
          <p className="font-inter font-normal text-[12px] text-white/30">
            &copy; 2025 FNATIC ORG BGMI. All rights reserved.
          </p>
        </div>
      </div>

      {/* Back to Top Button */}
      <button
        onClick={scrollToTop}
        className="fixed bottom-6 right-6 w-12 h-12 rounded-full flex items-center justify-center border z-50 transition-all duration-300 hover:scale-110"
        style={{
          background: 'rgba(255, 69, 0, 0.1)',
          borderColor: 'rgba(255, 69, 0, 0.3)',
          color: '#FF4500',
        }}
        onMouseEnter={(e) => {
          (e.currentTarget as HTMLElement).style.background =
            'rgba(255, 69, 0, 0.2)';
        }}
        onMouseLeave={(e) => {
          (e.currentTarget as HTMLElement).style.background =
            'rgba(255, 69, 0, 0.1)';
        }}
      >
        <svg
          width="20"
          height="20"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <polyline points="18 15 12 9 6 15" />
        </svg>
      </button>
    </footer>
  );
}
