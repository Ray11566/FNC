import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function JoinCommunity() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const leftRef = useRef<HTMLDivElement>(null);
  const rightRef = useRef<HTMLDivElement>(null);

  const [form, setForm] = useState({
    ign: '',
    discord: '',
    role: '',
    experience: '',
    reason: '',
  });

  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    if (!sectionRef.current || !leftRef.current || !rightRef.current) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        leftRef.current,
        { opacity: 0, x: -30 },
        {
          opacity: 1,
          x: 0,
          duration: 0.8,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );

      gsap.fromTo(
        rightRef.current,
        { opacity: 0, x: 30 },
        {
          opacity: 1,
          x: 0,
          duration: 0.8,
          delay: 0.2,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 3000);
  };

  const inputClass =
    'w-full bg-white/5 border border-white/10 text-white placeholder-white/30 px-4 py-3 font-inter text-[14px] outline-none focus:border-fnc-orange transition-colors duration-300';

  return (
    <section
      id="join-community"
      ref={sectionRef}
      className="relative w-full py-[120px] px-6 md:px-10"
      style={{ background: '#111111' }}
    >
      <div className="max-w-[1280px] mx-auto flex flex-col lg:flex-row gap-12 lg:gap-20">
        {/* Left Column */}
        <div ref={leftRef} className="lg:w-[55%] flex flex-col justify-center">
          <p className="font-rajdhani font-semibold text-[12px] uppercase tracking-[0.12em] text-fnc-orange mb-4">
            RECRUITMENT
          </p>
          <h2 className="font-rajdhani font-bold text-[36px] md:text-[48px] uppercase text-white leading-tight mb-4">
            JOIN THE SQUAD
          </h2>
          <p className="font-inter font-normal text-[16px] text-fnc-textMuted max-w-[420px] mb-8">
            Think you have what it takes to compete at the highest level? We're
            always scouting for exceptional talent.
          </p>
          <div
            className="w-[1px] h-20 hidden lg:block"
            style={{ background: 'rgba(255, 69, 0, 0.3)' }}
          />
        </div>

        {/* Right Column - Form */}
        <div ref={rightRef} className="lg:w-[45%]">
          <div
            className="p-8 md:p-10 border border-fnc-border"
            style={{
              background: 'rgba(20, 20, 20, 0.8)',
              backdropFilter: 'blur(10px)',
              WebkitBackdropFilter: 'blur(10px)',
            }}
          >
            <h3 className="font-rajdhani font-bold text-[18px] uppercase text-white mb-6">
              TRIAL REGISTRATION
            </h3>

            {submitted ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center border-2 border-fnc-orange">
                  <svg
                    width="32"
                    height="32"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="#FF4500"
                    strokeWidth="2"
                  >
                    <polyline points="20 6 9 17 4 12" />
                  </svg>
                </div>
                <p className="font-rajdhani font-bold text-[20px] text-white mb-2">
                  APPLICATION SENT!
                </p>
                <p className="font-inter text-[14px] text-fnc-textMuted">
                  We'll review your application and get back to you soon.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="flex flex-col gap-4">
                <input
                  type="text"
                  placeholder="In-Game Name"
                  className={inputClass}
                  value={form.ign}
                  onChange={(e) =>
                    setForm({ ...form, ign: e.target.value })
                  }
                  required
                />
                <input
                  type="text"
                  placeholder="Discord / Contact"
                  className={inputClass}
                  value={form.discord}
                  onChange={(e) =>
                    setForm({ ...form, discord: e.target.value })
                  }
                  required
                />
                <select
                  className={inputClass + ' appearance-none cursor-pointer'}
                  value={form.role}
                  onChange={(e) =>
                    setForm({ ...form, role: e.target.value })
                  }
                  required
                >
                  <option value="" disabled className="bg-[#141414]">
                    Preferred Role
                  </option>
                  <option value="IGL" className="bg-[#141414]">
                    IGL
                  </option>
                  <option value="Entry Assaulter" className="bg-[#141414]">
                    Entry Assaulter
                  </option>
                  <option value="Assaulter" className="bg-[#141414]">
                    Assaulter
                  </option>
                  <option value="Power Fragger" className="bg-[#141414]">
                    Power Fragger
                  </option>
                  <option value="Support" className="bg-[#141414]">
                    Support
                  </option>
                </select>
                <textarea
                  placeholder="Tournament Experience"
                  rows={4}
                  className={inputClass + ' resize-none'}
                  value={form.experience}
                  onChange={(e) =>
                    setForm({ ...form, experience: e.target.value })
                  }
                  required
                />
                <textarea
                  placeholder="Why join FNCORG?"
                  rows={4}
                  className={inputClass + ' resize-none'}
                  value={form.reason}
                  onChange={(e) =>
                    setForm({ ...form, reason: e.target.value })
                  }
                  required
                />
                <button
                  type="submit"
                  className="w-full font-rajdhani font-semibold text-[14px] uppercase tracking-[0.06em] bg-fnc-orange text-white py-3.5 hover:bg-fnc-orangeBright transition-all duration-300 hover:shadow-orangeSm"
                >
                  SEND APPLICATION
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
