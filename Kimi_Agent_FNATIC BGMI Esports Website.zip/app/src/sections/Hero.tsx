import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { FontLoader } from 'three/addons/loaders/FontLoader.js';
import { TextGeometry } from 'three/addons/geometries/TextGeometry.js';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

function createTextRing(containerId: string, text: string) {
  const container = document.getElementById(containerId);
  if (!container) return;
  const radius = 300;
  const chars = text.split('');
  const angleStep = 360 / chars.length;

  chars.forEach((char, i) => {
    const span = document.createElement('span');
    span.textContent = char === ' ' ? '\u00A0' : char;
    span.style.position = 'absolute';
    span.style.fontFamily = "'Rajdhani', sans-serif";
    span.style.fontWeight = '700';
    span.style.fontSize = '24px';
    span.style.color = '#FF4500';
    span.style.textTransform = 'uppercase';
    span.style.letterSpacing = '0.1em';
    span.style.backfaceVisibility = 'hidden';
    span.style.transform = `rotateY(${i * angleStep}deg) translateZ(${radius}px)`;
    container.appendChild(span);
  });
}

function initRingScrollAnimation() {
  ScrollTrigger.create({
    trigger: '.hero',
    start: 'top top',
    end: 'bottom top',
    scrub: true,
    onUpdate: (self) => {
      const spans = document.querySelectorAll('.text-ring span');
      const spread = 1 + self.progress * 2;
      spans.forEach((span) => {
        const el = span as HTMLElement;
        el.style.transform = el.style.transform.replace(
          /translateZ\([^)]+\)/,
          `translateZ(${300 * spread}px)`
        );
      });
    },
  });
}

export default function Hero() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const heroRef = useRef<HTMLDivElement>(null);
  const initRef = useRef(false);

  useEffect(() => {
    if (initRef.current) return;
    initRef.current = true;

    const canvasElement = canvasRef.current;
    if (!canvasElement) return;

    // Create Text Ring
    setTimeout(() => {
      createTextRing(
        'text-ring',
        'FIREPOWER & NEUTRALIZATION CORPS – OFFENSIVE RECON GROUP'
      );
      initRingScrollAnimation();
    }, 100);

    // Three.js setup
    const scene = new THREE.Scene();
    const camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
    const renderer = new THREE.WebGLRenderer({
      canvas: canvasElement,
      alpha: true,
    });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    const clock = new THREE.Clock();
    let textMesh: THREE.Mesh | null = null;
    let particleMaterial: THREE.ShaderMaterial | null = null;
    let animationId: number;

    function loadFont(): Promise<any> {
      return new Promise((resolve, reject) => {
        const loader = new FontLoader();
        loader.load(
          'https://unpkg.com/three@0.160.0/examples/fonts/helvetiker_bold.typeface.json',
          resolve,
          undefined,
          reject
        );
      });
    }

    function createTextMesh(font: unknown): THREE.Mesh {
      const geometry = new TextGeometry('FNCORG', {
        font: font as any,
        size: 0.25,
        depth: 0.05,
        curveSegments: 12,
      });

      geometry.computeBoundingBox();
      const centerOffset = new THREE.Vector3();
      geometry.boundingBox!.getCenter(centerOffset);
      geometry.translate(-centerOffset.x, -centerOffset.y, 0);

      const material = new THREE.MeshNormalMaterial({
        opacity: 0.8,
        transparent: true,
        wireframe: true,
      });

      material.onBeforeCompile = (shader: any) => {
        shader.uniforms.uTime = { value: 0 };
        shader.uniforms.uColor = { value: new THREE.Color('#FF4500') };

        shader.vertexShader = shader.vertexShader.replace(
          '#include <common>',
          `
          uniform float uTime;
          mat4 rotationMatrix(vec3 axis, float angle) {
            axis = normalize(axis);
            float s = sin(angle);
            float c = cos(angle);
            float oc = 1.0 - c;
            return mat4(
              oc * axis.x * axis.x + c, oc * axis.x * axis.y - axis.z * s, oc * axis.z * axis.x + axis.y * s, 0.0,
              oc * axis.x * axis.y + axis.z * s, oc * axis.y * axis.y + c, oc * axis.y * axis.z - axis.x * s, 0.0,
              oc * axis.z * axis.x - axis.y * s, oc * axis.y * axis.z + axis.x * s, oc * axis.z * axis.z + c, 0.0,
              0.0, 0.0, 0.0, 1.0
            );
          }
          `
        );

        shader.vertexShader = shader.vertexShader.replace(
          '#include <project_vertex>',
          `
          vec4 mvPosition = vec4(transformed, 1.0);
          float angle = uTime * 0.5 + mvPosition.y * 2.0;
          mvPosition = rotationMatrix(vec3(0.0, 1.0, 0.0), angle) * mvPosition;
          mvPosition.x += sin(uTime * 2.0 + mvPosition.y * 5.0) * 0.02;
          mvPosition = modelViewMatrix * mvPosition;
          gl_Position = projectionMatrix * mvPosition;
          `
        );

        shader.fragmentShader = shader.fragmentShader.replace(
          '#include <normal_fragment_maps>',
          'diffuseColor.rgb = uColor;'
        );

        material.userData.shader = shader;
      };

      return new THREE.Mesh(geometry, material);
    }

    function createParticlePlane(texture: THREE.Texture): THREE.Mesh {
      const geometry = new THREE.PlaneGeometry(2, 2);
      const material = new THREE.ShaderMaterial({
        uniforms: {
          uTexture: { value: texture },
          uMouse: { value: new THREE.Vector2(0.5, 0.5) },
          uTime: { value: 0 },
        },
        vertexShader: `
          varying vec2 vUv;
          void main() {
            vUv = uv;
            gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
          }
        `,
        fragmentShader: `
          uniform sampler2D uTexture;
          uniform vec2 uMouse;
          uniform float uTime;
          varying vec2 vUv;

          float circle(vec2 uv, vec2 circlePosition, float radius) {
            float dist = distance(circlePosition, uv);
            return 1.0 - smoothstep(0.0, radius, dist);
          }

          void main() {
            vec2 uv = vUv;
            float mouseDist = distance(uMouse, uv);
            float ripple = sin(mouseDist * 20.0 - uTime * 3.0) * 0.02;
            float strength = smoothstep(0.5, 0.0, mouseDist) * ripple;
            uv += strength;
            uv.x += sin(uv.y * 5.0 + uTime) * 0.01;
            vec4 texColor = texture2D(uTexture, uv);
            gl_FragColor = texColor;
          }
        `,
        transparent: true,
      });

      return new THREE.Mesh(geometry, material);
    }

    function animate() {
      animationId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      if (textMesh && textMesh.material && (textMesh.material as any).userData.shader) {
        (textMesh.material as any).userData.shader.uniforms.uTime.value = elapsedTime;
      }

      if (particleMaterial) {
        particleMaterial.uniforms.uTime.value = elapsedTime;
      }

      renderer.render(scene, camera);
    }

    function mount(font: unknown) {
      textMesh = createTextMesh(font);
      scene.add(textMesh);

      const textureLoader = new THREE.TextureLoader();
      textureLoader.load('/images/hero-character.jpg', (texture) => {
        texture.minFilter = THREE.LinearFilter;
        const plane = createParticlePlane(texture);
        particleMaterial = plane.material as THREE.ShaderMaterial;
        plane.position.z = -0.5;
        scene.add(plane);
        animate();
      });
    }

    loadFont().then(mount);

    // Mouse tracking
    const handleMouseMove = (event: MouseEvent) => {
      if (!particleMaterial) return;
      const rect = canvasElement.getBoundingClientRect();
      particleMaterial.uniforms.uMouse.value.x =
        (event.clientX - rect.left) / rect.width;
      particleMaterial.uniforms.uMouse.value.y =
        1.0 - (event.clientY - rect.top) / rect.height;
    };

    window.addEventListener('mousemove', handleMouseMove);

    // GSAP Scroll-driven camera pullback
    const tl = gsap.timeline({
      scrollTrigger: {
        trigger: canvasElement,
        start: 'top top',
        end: 'bottom top',
        scrub: true,
      },
    });
    tl.to(camera.position, { z: 5, y: 0.5, duration: 1 }, 0);

    // Resize handler
    const handleResize = () => {
      renderer.setSize(window.innerWidth, window.innerHeight);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    };
    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
      tl.kill();
      renderer.dispose();
    };
  }, []);

  const scrollToPlayers = () => {
    const el = document.getElementById('team-players');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToManagement = () => {
    const el = document.getElementById('team-management');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section ref={heroRef} className="hero relative w-full min-h-[100dvh] overflow-hidden">
      {/* Three.js Canvas */}
      <canvas
        ref={canvasRef}
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          zIndex: 1,
        }}
      />

      {/* 3D Text Ring */}
      <div
        style={{
          perspective: '1000px',
          width: '100%',
          height: '200px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          position: 'absolute',
          top: '15%',
          zIndex: 2,
          pointerEvents: 'none',
        }}
      >
        <div
          id="text-ring"
          className="text-ring"
          style={{
            position: 'relative',
            width: 0,
            height: 0,
            transformStyle: 'preserve-3d',
            animation: 'spinRing 20s linear infinite',
          }}
        />
      </div>

      {/* Hero Content - Lower Left */}
      <div
        className="absolute z-[3] px-6 md:px-[5%]"
        style={{
          bottom: '15%',
          left: 0,
          maxWidth: '640px',
        }}
      >
        <p
          className="font-rajdhani font-semibold text-[12px] uppercase tracking-[0.12em] text-fnc-orange mb-4"
        >
          BGMI ESPORTS UNIT
        </p>

        <h1
          className="font-rajdhani font-bold text-[56px] md:text-[96px] uppercase leading-none tracking-[-0.02em] text-white mb-4"
          style={{
            textShadow: '0 0 60px rgba(255, 69, 0, 0.5)',
          }}
        >
          FNCORG
        </h1>

        <p className="font-rajdhani font-normal text-[16px] md:text-[20px] text-fnc-textMuted mb-2">
          Firepower & Neutralization Corps – Offensive Recon Group
        </p>

        <p className="font-inter font-normal text-[14px] text-fnc-textMuted mb-8">
          Established: October 1, 2025
        </p>

        <div className="flex flex-wrap gap-4">
          <button
            onClick={scrollToPlayers}
            className="font-rajdhani font-semibold text-[14px] uppercase tracking-[0.06em] bg-fnc-orange text-white px-8 py-3.5 hover:bg-fnc-orangeBright transition-all duration-300 hover:shadow-orange"
          >
            MEET OUR PLAYERS
          </button>
          <button
            onClick={scrollToManagement}
            className="font-rajdhani font-semibold text-[14px] uppercase tracking-[0.06em] border border-fnc-border text-fnc-orange bg-transparent px-8 py-3.5 hover:bg-[rgba(255,69,0,0.1)] transition-all duration-300"
          >
            TEAM MANAGEMENT
          </button>
        </div>
      </div>
    </section>
  );
}
