interface FncorgLogoProps {
  className?: string;
  size?: number;
}

export default function FncorgLogo({ className = '', size = 32 }: FncorgLogoProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Outer shield */}
      <path
        d="M32 4L8 16V32C8 46.4 18.4 58.4 32 62C45.6 58.4 56 46.4 56 32V16L32 4Z"
        stroke="#FF4500"
        strokeWidth="2"
        fill="none"
      />
      {/* Inner shield */}
      <path
        d="M32 10L14 19V32C14 43.2 21.6 52.8 32 56C42.4 52.8 50 43.2 50 32V19L32 10Z"
        stroke="#FF4500"
        strokeWidth="1.5"
        fill="rgba(255, 69, 0, 0.1)"
      />
      {/* F letter */}
      <path
        d="M22 24H38M22 24V42M22 32H34"
        stroke="#FF4500"
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      {/* Wings */}
      <path
        d="M8 20L4 16L8 18M56 20L60 16L56 18"
        stroke="#FF4500"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
