import { useState, useEffect } from 'react';
import FncorgLogo from './FncorgLogo';

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 100);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
      setMobileOpen(false);
    }
  };

  return (
    <nav
      className="fixed top-0 left-0 right-0 z-[100] transition-all duration-400"
      style={{
        background: scrolled ? 'rgba(10, 10, 10, 0.6)' : 'transparent',
        backdropFilter: scrolled ? 'blur(20px)' : 'none',
        WebkitBackdropFilter: scrolled ? 'blur(20px)' : 'none',
        borderBottom: '1px solid rgba(255, 69, 0, 0.1)',
        height: '72px',
      }}
    >
      <div className="max-w-[1280px] mx-auto px-6 md:px-10 h-full flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <FncorgLogo size={32} />
          <span className="font-rajdhani font-bold text-[18px] text-white tracking-wide">
            FNATIC ORG
          </span>
        </div>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          <button
            onClick={() => scrollToSection('team-players')}
            className="font-rajdhani font-semibold text-[13px] uppercase tracking-[0.06em] text-fnc-textMuted hover:text-fnc-orange transition-colors duration-300"
          >
            TEAM PLAYERS
          </button>
          <button
            onClick={() => scrollToSection('team-management')}
            className="font-rajdhani font-semibold text-[13px] uppercase tracking-[0.06em] text-fnc-textMuted hover:text-fnc-orange transition-colors duration-300"
          >
            TEAM MANAGEMENT
          </button>
        </div>

        {/* Mobile Hamburger */}
        <button
          className="md:hidden flex flex-col gap-1.5 p-2"
          onClick={() => setMobileOpen(!mobileOpen)}
        >
          <span
            className="block w-6 h-0.5 bg-white transition-transform duration-300"
            style={{
              transform: mobileOpen ? 'rotate(45deg) translateY(4px)' : 'none',
            }}
          />
          <span
            className="block w-6 h-0.5 bg-white transition-opacity duration-300"
            style={{ opacity: mobileOpen ? 0 : 1 }}
          />
          <span
            className="block w-6 h-0.5 bg-white transition-transform duration-300"
            style={{
              transform: mobileOpen ? 'rotate(-45deg) translateY(-4px)' : 'none',
            }}
          />
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div
          className="md:hidden absolute top-[72px] left-0 right-0 py-6 px-6 flex flex-col gap-4"
          style={{
            background: 'rgba(10, 10, 10, 0.9)',
            backdropFilter: 'blur(30px)',
            WebkitBackdropFilter: 'blur(30px)',
          }}
        >
          <button
            onClick={() => scrollToSection('team-players')}
            className="font-rajdhani font-semibold text-[13px] uppercase tracking-[0.06em] text-fnc-textMuted hover:text-fnc-orange transition-colors duration-300 text-left"
          >
            TEAM PLAYERS
          </button>
          <button
            onClick={() => scrollToSection('team-management')}
            className="font-rajdhani font-semibold text-[13px] uppercase tracking-[0.06em] text-fnc-textMuted hover:text-fnc-orange transition-colors duration-300 text-left"
          >
            TEAM MANAGEMENT
          </button>
        </div>
      )}
    </nav>
  );
}
